from kivy.uix.screenmanager import Screen
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.audio import SoundLoader

class MenuScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = GridLayout(cols=1, spacing=20, padding=60)
        layout.add_widget(Label(text="FNaF Extended", font_size=48))
        btns = [
            ("Classic Night", "game"),
            ("Extended Custom Night", "custom_night"),
            ("Sandbox Mode", "sandbox"),
            ("Animatronic Mode", "animatronic"),
            ("Settings", "settings"),
            ("Quit", "quit")
        ]
        for text, mode in btns:
            btn = Button(text=text, font_size=32)
            btn.bind(on_release=lambda inst, m=mode: self.goto_mode(m))
            layout.add_widget(btn)
        # Play a menu sound for fun
        self.menu_sound = SoundLoader.load('assets/sounds/menu.wav')
        if self.menu_sound:
            self.menu_sound.play()
        self.add_widget(layout)

    def goto_mode(self, mode):
        if mode == 'quit':
            from kivy.app import App; App.get_running_app().stop()
        else:
            self.manager.current = mode