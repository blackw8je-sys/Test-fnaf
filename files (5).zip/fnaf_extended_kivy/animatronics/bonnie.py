from .base import AnimatronicBase

class Bonnie(AnimatronicBase):
    def decide_next_move(self, game_state):
        # Example: if left hall open, approach, else wait or adapt
        pass