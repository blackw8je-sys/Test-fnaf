from kivy.uix.screenmanager import Screen
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label

class CustomNightScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = GridLayout(cols=1, spacing=20, padding=60)
        layout.add_widget(Label(text="Custom Night (AI 0–99 sliders, coming soon)", font_size=32))
        layout.add_widget(Button(text="Back to Menu", font_size=24, on_release=self.back_to_menu))
        self.add_widget(layout)
    def back_to_menu(self, instance):
        self.manager.current = 'menu'