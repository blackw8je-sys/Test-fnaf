# FNaF Extended (Kivy/Android Ready)

## Project Structure

- `main.py`: Entrypoint, screen manager to handle game states
- `menu.py`, `settings.py`, `custom_night.py`, `sandbox_mode.py`, `animatronic_mode.py`: Modular screens for each mode
- `ai_nightguard.py`: Adaptive night guard AI stub
- `animatronics/`: Each animatronic (Bonnie, Chica, etc.) as a Python class
- `assets/`: Place your images, audio, fonts here
- `buildozer.spec`: For APK building
- `README.md`: You are here

## How to Build APK

1. **Install prerequisites:**
   - Linux recommended (use WSL on Windows)
   - `pip install buildozer`
   - `sudo apt update && sudo apt install -y python3-pip python3-setuptools git python3 python3-virtualenv zip unzip openjdk-17-jdk`
2. **Run:**
   ```bash
   buildozer init
   buildozer -v android debug
   ```
3. **Connect your Android phone, or find the APK in:**
   ```
   ./bin/
   ```

## How to Run on Desktop

```bash
python3 main.py
```
*(Install [Kivy](https://kivy.org/doc/stable/gettingstarted/installation.html) with `pip install kivy` first)*

## How to Expand

- Add screens and features to each mode by editing their respective module.
- Place all images/audio into `assets/`.
- Animatronic logic lives in the `animatronics/` package.

## Notes

- Full FNaF game logic to be added to each stub.
- Suitable for further expansion, cross-platform builds.
- Sound & image assets not included: add your art/audio into `assets/`.
