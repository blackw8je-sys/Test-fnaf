# You will implement the smart night guard AI here (stub for structure)
class NightGuardAI:
    def __init__(self, difficulty='medium'):
        self.difficulty = difficulty
    def decide(self, game_state):
        # Decision logic, e.g. close/open doors, camera check, modeled by difficulty
        pass