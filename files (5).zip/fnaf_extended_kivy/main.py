from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from menu import MenuScreen
from settings import SettingsScreen
from custom_night import CustomNightScreen
from sandbox_mode import SandboxScreen
from animatronic_mode import AnimatronicScreen

class FNaFScreenManager(ScreenManager):
    pass

class FNaFApp(App):
    def build(self):
        sm = FNaFScreenManager()
        sm.add_widget(MenuScreen(name='menu'))
        sm.add_widget(SettingsScreen(name='settings'))
        sm.add_widget(CustomNightScreen(name='custom_night'))
        sm.add_widget(SandboxScreen(name='sandbox'))
        sm.add_widget(AnimatronicScreen(name='animatronic'))
        return sm

if __name__ == '__main__':
    FNaFApp().run()