from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.audio import SoundLoader
from kivy.uix.image import Image
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

class MenuScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        bl = BoxLayout(orientation='vertical')
        bl.add_widget(Image(source='assets/images/title.png'))
        btn = Button(text='Start Game', font_size=36)
        btn.bind(on_release=self.start_game)
        bl.add_widget(btn)
        self.add_widget(bl)
        snd = SoundLoader.load('assets/sounds/menu.wav')
        if snd: snd.play()
    def start_game(self, instance):
        self.manager.current = "game"

class GameScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        bl = BoxLayout(orientation='vertical')
        self.img = Image(source='assets/images/bonnie.png')
        bl.add_widget(self.img)
        btn = Button(text='Play JumpScare', font_size=36)
        btn.bind(on_release=self.jumpscare)
        bl.add_widget(btn)
        self.add_widget(bl)
    def jumpscare(self, instance):
        snd = SoundLoader.load('assets/sounds/jumpscare.wav')
        if snd: snd.play()
        self.img.source = 'assets/images/jumpscare.png'

class FNaFApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(MenuScreen(name='menu'))
        sm.add_widget(GameScreen(name='game'))
        return sm

if __name__ == '__main__':
    FNaFApp().run()