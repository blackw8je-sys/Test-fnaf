class PlayableAnimatronic:
    def __init__(self, name, rooms, abilities):
        self.name = name
        self.current_room = rooms[0]
        self.abilities = abilities

    def move(self, possible_rooms):
        # UI to pick next room
        pass

    def use_ability(self, ability_idx):
        # UI to trigger screamer, disable light, etc.
        pass

class NightGuardAI:
    def __init__(self, difficulty):
        self.difficulty = difficulty
        # The higher the difficulty, the faster the guard reacts, strategizes

    def decide(self, game_state):
        # Use probability, ML, or decision trees to simulate a smart night guard
        pass