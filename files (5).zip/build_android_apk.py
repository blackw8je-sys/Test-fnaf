import os
print("Ensure all code uses Kivy for this build!")
os.system("buildozer android debug")
print("Check bin/ folder for your APK.")