#!/bin/bash

# Portable Python/Kivy signed APK builder & installer
# Requirements: buildozer, proper buildozer.spec, adb (Android Debug Bridge)
# Usage: ./portable_build_release.sh [APPNAME]
# Default app name is fnaf_extended_kivy

APPNAME="${1:-fnaf_extended_kivy}"
APK_BIN_PATH="bin/${APPNAME}-release.apk"

set -e

echo "== Cleaning previous builds =="
buildozer android clean

echo "== Building signed release APK =="
buildozer -v android release

if [ ! -f "$APK_BIN_PATH" ]; then
  release_apk=$(find bin -name '*-release.apk' | head -n1)
  if [ -z "$release_apk" ]; then
    echo "Could not find any signed release APK in bin/"
    exit 1
  fi
  APK_BIN_PATH="$release_apk"
fi

echo "== Signed APK built at: $APK_BIN_PATH =="

# Check for android-tools-adb
if ! command -v adb &>/dev/null; then
  echo "adb not found! Installing android-tools-adb (sudo required)..."
  sudo apt update
  sudo apt install -y android-tools-adb
fi

# Check if device is available via adb
if ! adb devices | grep -q "device$"; then
  echo "No device detected via adb."
  echo "Please: (1) Enable USB debugging on your Android device,"
  echo "        (2) Connect with USB,"
  echo "        (3) Accept the fingerprint prompt,"
  echo "        (4) Run 'adb devices' and check your device."
  exit 1
fi

echo
while true; do
    read -p "Install $APK_BIN_PATH onto the detected Android device? (y/n): " yn
    case $yn in
        [Yy]* )
            echo "== Installing APK =="
            adb install -r "$APK_BIN_PATH"
            echo "== APK installation complete! =="
            break
            ;;
        [Nn]* )
            echo "Aborting APK install. APK is ready in $APK_BIN_PATH"
            break
            ;;
        * ) echo "Please answer yes (y) or no (n).";;
    esac
done