# FNaF Extended (Kivy/Android Ready)

## Project Structure

- Modular code in `.py` files + `assets/` for sounds/images.
- `buildozer.spec` for configuration.

## To Run on Desktop
```bash
pip install kivy
python3 main.py
```

## To Build APK for Android
1. Install requirements (Linux or WSL):
   ```
   pip install buildozer
   sudo apt update && sudo apt install -y openjdk-17-jdk python3-pip unzip zip
   ```
2. Build:
   ```
   buildozer -v android debug
   ```
   The APK will be in `./bin/`.

3. For a **signed release APK** for Play Store:
   - Generate a keystore and fill release keys in `buildozer.spec`.
   - Then:  
     ```
     buildozer -v android release
     ```

## GitHub Actions APK CI (auto-build on push)

Add this as `.github/workflows/android-apk.yml` in your repo:

```yaml
name: Build Android APK
on:
  push:
    branches: [main]
jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    - name: Install dependencies
      run: |
        sudo apt-get update
        sudo apt-get install -y python3-pip git zip unzip openjdk-17-jdk
        python3 -m pip install --user --upgrade pip
    - name: Install Buildozer
      run: pip3 install buildozer
    - name: Build APK
      run: buildozer -v android debug
    - name: Upload APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: fnaf_extended_kivy.apk
        path: bin/*.apk
```

*(For Play Store release/autosigning, NEVER upload your secret keystore! Use repo secrets + encrypted upload: [Guide](https://medium.com/@mailtomyself789/how-to-sign-apk-debug-and-release-in-github-actions-169235b919db))*

----
Place your sounds/images into `assets/`, finish UI/game logic, and you’re ready for both development and Play Store deployment!