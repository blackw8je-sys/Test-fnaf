import os
os.system(
    "pyinstaller --noconfirm --onefile --windowed --add-data 'assets;assets' main.py"
)
print("EXE built successfully. See /dist for output.")