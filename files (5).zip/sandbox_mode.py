from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.togglebutton import ToggleButton

class SandboxScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=60, spacing=20)
        layout.add_widget(Label(text="Sandbox Mode", font_size=44))
        self.toggle_inf_power = ToggleButton(text="Infinite Power: OFF", state="normal", font_size=28)
        self.toggle_inf_power.bind(on_press=self.toggle_inf_power_cb)
        layout.add_widget(self.toggle_inf_power)
        layout.add_widget(Button(text="Back", font_size=30, on_release=self.back))
        self.add_widget(layout)

    def toggle_inf_power_cb(self, instance):
        instance.text = "Infinite Power: ON" if instance.state == "down" else "Infinite Power: OFF"

    def back(self, instance):
        self.manager.current = 'menu'