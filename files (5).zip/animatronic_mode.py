from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button

class AnimatronicScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', spacing=20, padding=60)
        layout.add_widget(Label(text="Play as Animatronics!", font_size=44))
        layout.add_widget(Label(text="Attack strategy & abilities UI coming soon!", font_size=22))
        btn = Button(text='Back', font_size=30)
        btn.bind(on_release=self.back)
        layout.add_widget(btn)
        self.add_widget(layout)
    def back(self, instance):
        self.manager.current = 'menu'