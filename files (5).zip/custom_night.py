from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.slider import Slider

class CustomNightScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=50, spacing=15)
        layout.add_widget(Label(text="Custom Night", font_size=48))
        # Example AI sliders
        layout.add_widget(Label(text="Bonnie AI (0–99)", font_size=28))
        self.bonnie_ai = Slider(min=0, max=99, value=20)
        layout.add_widget(self.bonnie_ai)
        layout.add_widget(Label(text="Chica AI (0–99)", font_size=28))
        self.chica_ai = Slider(min=0, max=99, value=15)
        layout.add_widget(self.chica_ai)
        btn = Button(text='Back', font_size=30, on_release=self.go_back)
        layout.add_widget(btn)
        self.add_widget(layout)
    def go_back(self, instance):
        self.manager.current = 'menu'