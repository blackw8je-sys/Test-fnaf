from .base import AnimatronicBase

class Bonnie(AnimatronicBase):
    def decide_next_move(self, game_state):
        # e.g., implement strategic hallway movement here
        pass