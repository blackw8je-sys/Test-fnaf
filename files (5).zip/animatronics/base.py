class AnimatronicBase:
    def __init__(self, name, difficulty):
        self.name = name
        self.difficulty = difficulty
    def decide_next_move(self, game_state):
        pass