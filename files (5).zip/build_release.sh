#!/bin/bash

# This script will:
# 1. Clean the build to avoid issues
# 2. Build a signed release APK
# 3. Optionally, install the APK onto a connected Android device

# Exit on error
set -e

APPNAME="fnaf_extended_kivy"
APK_BIN_PATH="bin/${APPNAME}-release.apk" # Change this if your app name is different

echo "===== Cleaning previous builds ====="
buildozer android clean

echo "===== Building signed release APK ====="
buildozer -v android release

echo "===== APK build complete ====="
if [ ! -f "$APK_BIN_PATH" ]; then
  # Try to find the apk by pattern
  release_apk=$(find bin -name "*-release.apk" | head -n1)
  if [ -z "$release_apk" ]; then
    echo "!!! Could not find the release APK. Check the bin/ directory manually."
    exit 1
  else
    APK_BIN_PATH="$release_apk"
  fi
fi

echo "Signed APK located at: $APK_BIN_PATH"

while true; do
    read -p "Do you want to install the APK onto a connected Android device? (y/n): " yn
    case $yn in
        [Yy]* )
            if ! command -v adb &>/dev/null; then
                echo "adb not found! Please install Android platform-tools and ensure adb is in your PATH."
                exit 1
            fi
            echo "Installing $APK_BIN_PATH to device..."
            adb install -r "$APK_BIN_PATH"
            echo "Installation complete!"
            break;;
        [Nn]* ) break;;
        * ) echo "Please answer (y)es or (n)o.";;
    esac
done