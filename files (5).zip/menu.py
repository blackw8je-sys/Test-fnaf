from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.core.audio import SoundLoader

class MenuScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=50, spacing=20)
        layout.add_widget(Label(text="FNaF Extended", font_size=60, bold=True, color=(1,0.85,0.3,1)))
        layout.add_widget(Image(source='assets/images/title.png', size_hint=(1,0.6)))
        menu_sound = SoundLoader.load('assets/sounds/menu.wav')
        if menu_sound:
            menu_sound.play()
        buttons = [
            ("Classic Night", "game"),
            ("Extended Custom Night", "custom_night"),
            ("Sandbox Mode", "sandbox"),
            ("Animatronic Mode", "animatronic"),
            ("Settings", "settings"),
            ("Quit", "quit")
        ]
        for text, mode in buttons:
            btn = Button(text=text, font_size=32, size_hint=(1,0.15))
            btn.bind(on_release=lambda btn, m=mode: self.goto_mode(m))
            layout.add_widget(btn)
        self.add_widget(layout)

    def goto_mode(self, mode):
        if mode == 'quit':
            from kivy.app import App; App.get_running_app().stop()
        else:
            self.manager.current = mode