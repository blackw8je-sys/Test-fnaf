# Main stub for AI Night Guard
class NightGuardAI:
    def __init__(self, difficulty='medium'):
        self.difficulty = difficulty
    def decide(self, game_state):
        # Add full decision logic based on difficulty
        return "open" if self.difficulty == "easy" else "close"