from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.slider import Slider

class SettingsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', spacing=15, padding=50)
        layout.add_widget(Label(text="Settings", font_size=50))
        # Example slider for sound volume
        layout.add_widget(Label(text="Sound Volume", font_size=30))
        self.vol = Slider(min=0,max=1,value=0.7)
        layout.add_widget(self.vol)
        layout.add_widget(Button(text="Back", font_size=28, on_release=self.back))
        self.add_widget(layout)

    def back(self, instance):
        self.manager.current = 'menu'